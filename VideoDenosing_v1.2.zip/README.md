# VideoDenoising_AKNN_NLM
a video denoising algorithm based on NLM and AKNN, referred to aritcle 'A high-quality video denoising algorithm based on reliable motion estimation'
